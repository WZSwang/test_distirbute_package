# -*- coding: utf-8 -*-
# Date: 2019/1/15

name = 'example_pkg'
